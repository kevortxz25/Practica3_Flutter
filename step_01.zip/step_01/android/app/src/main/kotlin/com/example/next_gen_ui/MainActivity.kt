package com.example.next_gen_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
